import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import SMOTE

# Load dataset
df = pd.read_excel("stroke.xlsx")

# Drop ID column if present
df = df.drop(columns=["id"], errors="ignore")

# Handle missing values
df["bmi"].fillna(df["bmi"].mean(), inplace=True)
df["avg_glucose_level"].fillna(df["avg_glucose_level"].mean(), inplace=True)

# Standardize categorical values (convert to lowercase)
df = df.applymap(lambda x: x.lower().strip() if isinstance(x, str) else x)

# Define categorical feature mappings (ensures no unseen labels)
category_mappings = {
    "gender": ["male", "female", "other"],
    "ever_married": ["no", "yes"],
    "work_type": ["private", "self-employed", "govt_job", "children", "never_worked"],
    "Residence_type": ["urban", "rural"],
    "smoking_status": ["never smoked", "formerly smoked", "smokes", "unknown"]
}

# Label Encoding
label_encoders = {}
for col, categories in category_mappings.items():
    le = LabelEncoder()
    le.fit(categories)  # Fit using predefined categories
    df[col] = le.transform(df[col])  # Encode values
    label_encoders[col] = le  # Save encoder for later use

# Features and Target
X = df.drop(columns=["stroke"])
y = df["stroke"]

# Handle Class Imbalance with SMOTE
smote = SMOTE(sampling_strategy=0.5, random_state=42)
X_resampled, y_resampled = smote.fit_resample(X, y)

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X_resampled, y_resampled, test_size=0.2, random_state=42, stratify=y_resampled)

# Feature Scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train Model
model = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
model.fit(X_train, y_train)

# Save Model, Scaler & Encoders
with open("stroke_model.pkl", "wb") as model_file:
    pickle.dump(model, model_file)

with open("scaler.pkl", "wb") as scaler_file:
    pickle.dump(scaler, scaler_file)

with open("label_encoders.pkl", "wb") as encoder_file:
    pickle.dump(label_encoders, encoder_file)

print("✅ Model, Scaler, and Label Encoders saved successfully!")